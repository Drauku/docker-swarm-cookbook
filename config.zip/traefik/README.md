Document Traefik config here.
